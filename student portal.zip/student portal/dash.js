document.addEventListener('DOMContentLoaded', () => {
    const registrationForm = document.getElementById('registration-form');
    const studentTable = document.getElementById('student-table').querySelector('tbody');
    const dataTableContainer = document.querySelector('.data-table-container');
    const clearBtn = document.querySelector('.clear-btn');
    const submitBtn = document.querySelector('.submit-btn');

    let isEditing = false;
    let editingRow = null;

    // Handle form submission
    registrationForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Get all form data as an object
        const formData = {
            uid: document.getElementById('uid').value,
            name: document.getElementById('name').value,
            address: document.getElementById('address').value,
            mobile: document.getElementById('mobile').value,
            age: document.getElementById('age').value,
            nationality: document.getElementById('nationality').value,
            identityNo: document.getElementById('identity-no').value,
            city: document.getElementById('city').value,
            state: document.getElementById('state').value,
            pinCode: document.getElementById('pin-code').value,
            country: document.getElementById('country').value,
        };

        // If editing, update the student; otherwise, add a new one
        if (isEditing) {
            updateStudent(formData);
        } else {
            addStudent(formData);
        }

        clearForm(); // Clear the form after submission
    });

    // Handle button clicks in the table
    studentTable.addEventListener('click', (e) => {
        const target = e.target;
        const row = target.closest('tr');
        if (!row) return;

        if (target.classList.contains('table-edit-btn')) {
            editStudent(row);
        } else if (target.classList.contains('table-delete-btn')) {
            deleteStudent(row);
        }
    });

    // Clear form button
    clearBtn.addEventListener('click', clearForm);

    // Function to add a new student to the table with ALL details
    function addStudent(data) {
        const newRow = studentTable.insertRow();
        newRow.setAttribute('data-uid', data.uid); // Store UID on the row for easier lookup

        newRow.innerHTML = `
            <td data-label="UID">${data.uid}</td>
            <td data-label="Name">${data.name}</td>
            <td data-label="Mobile No.">${data.mobile}</td>
            <td data-label="Age">${data.age}</td>
            <td data-label="Nationality">${data.nationality}</td>
            <td data-label="Identity No.">${data.identityNo}</td>
            <td data-label="Address">${data.address}</td>
            <td data-label="City">${data.city}</td>
            <td data-label="State">${data.state}</td>
            <td data-label="Pin Code">${data.pinCode}</td>
            <td data-label="Country">${data.country}</td>
            <td>
                <button class="table-edit-btn">Edit</button>
                <button class="table-delete-btn">Delete</button>
            </td>
        `;

        // Show the table after the first entry
        dataTableContainer.classList.remove('hidden');
    }

    // Function to update an existing student in the table
    function updateStudent(data) {
        const cells = editingRow.querySelectorAll('td');

        cells[0].textContent = data.uid;
        cells[1].textContent = data.name;
        cells[2].textContent = data.mobile;
        cells[3].textContent = data.age;
        cells[4].textContent = data.nationality;
        cells[5].textContent = data.identityNo;
        cells[6].textContent = data.address;
        cells[7].textContent = data.city;
        cells[8].textContent = data.state;
        cells[9].textContent = data.pinCode;
        cells[10].textContent = data.country;

        // Reset the form state
        submitBtn.textContent = 'Register Student';
        isEditing = false;
        editingRow = null;
    }

    // Function to populate the form for editing a student
    function editStudent(row) {
        const cells = row.querySelectorAll('td');

        document.getElementById('uid').value = cells[0].textContent;
        document.getElementById('name').value = cells[1].textContent;
        document.getElementById('mobile').value = cells[2].textContent;
        document.getElementById('age').value = cells[3].textContent;
        document.getElementById('nationality').value = cells[4].textContent;
        document.getElementById('identity-no').value = cells[5].textContent;
        document.getElementById('address').value = cells[6].textContent;
        document.getElementById('city').value = cells[7].textContent;
        document.getElementById('state').value = cells[8].textContent;
        document.getElementById('pin-code').value = cells[9].textContent;
        document.getElementById('country').value = cells[10].textContent;

        // Change button text and set editing state
        submitBtn.textContent = 'Update Student';
        isEditing = true;
        editingRow = row;

        // Scroll to the top of the form for easy editing
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Function to delete a student from the table
    function deleteStudent(row) {
        if (confirm('Are you sure you want to delete this student?')) {
            row.remove();
            // Optional: Hide the table if it becomes empty
            if (studentTable.rows.length === 0) {
                dataTableContainer.classList.add('hidden');
            }
        }
    }

    // Function to clear all form fields
    function clearForm() {
        registrationForm.reset();
        submitBtn.textContent = 'Register Student';
        isEditing = false;
        editingRow = null;
    }
});